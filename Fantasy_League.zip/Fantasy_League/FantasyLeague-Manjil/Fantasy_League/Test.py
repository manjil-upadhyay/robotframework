FantasyLeagueURL		=	"https://fantasyleague.aecordigitalqa.com/"
PasswordProtectTB		=	'//*[@name="site-password-protected"]'
PassworProtectTBVal		=	'fle@gue'
ConfirmBTN				=	'//*[@type="submit"]'
LoginBTN				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/login"]'
EmailTB					=	'//*[@id="email"]'
EmailTBVal				=	'rstenson@aecordigital.com'
PasswordTB				=	'id=password'
PassworfTBVal			=	'password'
LoginButton				=	'//*[@class="btn btn-primary btn-block"]'
UserHeaderDD			=	'//*[@id="page-header-user-dropdown"]'
LogoutOption			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/logout"]'
GoogleLink				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/auth/google"]'
GoogleEmailTB			=	'//*[@id="identifierId"]'
GoogleEmailTBVal		=	'aecortest2019@gmail.com'
GoogleNextBTN			=	'//*[@id="identifierNext"]'
GooglePasswordTB		=	'//*[@name="password"]'


