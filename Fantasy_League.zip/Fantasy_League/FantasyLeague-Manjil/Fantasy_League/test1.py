FantasyLeagueURL		=	'https://fantasyleague.aecordigitalqa.com/'
PasswordProtectTB		=	'//*[@name="site-password-protected"]'
PassworProtectTBVal		=	'fle@gue'
ConfirmBTN				=	'//*[@type="submit"]'
LoginBTN				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/login"]'
EmailTB					=	'//*[@id="email"]'
EmailTBVal				=	'rstenson@aecordigital.com'
PasswordTB				=	'id=password'
PassworfTBVal			=	'password'
LoginButton				=	'//*[@class="btn btn-primary btn-block"]'
UserHeaderDD			=	'//*[@id="page-header-user-dropdown"]'
LogoutOption			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/logout"]'
GoogleLink				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/auth/google"]'
GoogleEmailTB			=	'//*[@id="identifierId"]'
GoogleEmailTBVal		=	'aecortest2019@gmail.com'
GoogleNextBTN			=	'//*[@id="identifierNext"]'
GooglePasswordTB		=	'//*[@name="password"]'
GooglePasswordTBVal		=	'password'
GooglePasswordNextBTN	=	'//*[@id="passwordNext"]'
FacebookLink			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/auth/facebook"]'
FacebookEmailVal		=	'sandeep.patel@aecordigital.com'
FacebookPasswordTB		=	'//*[@id="pass"]'
FacebookPasswordTBVal	=	'aecor12345'
FacebookLoginBTN		=	'//*[@id="loginbutton"]'
FacebookCreateLeagueLnk	=	'//a[@href="https://fantasyleague.aecordigitalqa.com/manage/division/create"]'	
#======================Create,edit,delete Admin user==================================
UserDD					=	'xpath=//*[@id="sidebar-scroll"]/div/div[3]/ul/li[2]/a'
AdminUser				=	'xpath=//*[@id="sidebar-scroll"]/div/div[3]/ul/li[2]/ul/li[1]/a'
AddNewAdminBTN			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/admin/users/create"]'
FirstNameTB				=	'//*[@name="first_name"]'
FirstNameTBVal			=	'Sandeep'
LastNameTB				=	'//*[@name="last_name"]'
LastNameTBval			=	'Patel'
AdminUerEmailId			=	'sandeep.patel966@aecordigital.com'
UserTypeDD				=	'//*[@id="select2-role-container"]'
UserTypeVal				=	'//*[contains@id,"select2-role-result") and contains(@id,"-superadmin")]'
CreateAdminBTN			=	'//*[@id="main-container"]/div/form/div[2]/button'
FirstNameSearchTB		=	'//*[@id="filter-term"]'
SearchBTN				=	'//*[@id="main-container"]/div/form/div/div[1]/div/button'
CustomerIDField			=	'//*[@id="DataTables_Table_0"]/tbody/tr/td[1]'
#CustAdminIdeditURL		=	'https://fantasyleague.aecordigitalqa.com/admin/users/${AdminID}/edit'
FirstNameUpdateVal		=	'Sandeep Update'
LastNameUpdateVal		=	'Patel Update'
UpdateEmailVal			=	'sandeep.patel96@aecordigital.com'
UpdateUserBTN			=	'//*[@id="main-container"]/div/form/div[2]/button'
DeleteIcon				=	'//*[@class="btn btn-sm btn-circle btn-alt-danger mr-5 mb-5 delete-confirmation-button"]'
OptionYes				=	'//*[@aria-label="Yes, delete it!"]'





















.





FantasyLeagueURL		=	"https://fantasyleague.aecordigitalqa.com/"
PasswordProtectTB		=	'//*[@name="site-password-protected"]'
PassworProtectTBVal		=	'fle@gue'
ConfirmBTN				=	'//*[@type="submit"]'
LoginBTN				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/login"]'
EmailTB					=	'//*[@id="email"]'
EmailTBVal				=	'rstenson@aecordigital.com'
PasswordTB				=	'id=password'
PassworfTBVal			=	'password'
LoginButton				=	'//*[@class="btn btn-primary btn-block"]'
UserHeaderDD			=	'//*[@id="page-header-user-dropdown"]'
LogoutOption			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/logout"]'
GoogleLink				=	'//a[@href="https://fantasyleague.aecordigitalqa.com/auth/google"]'
GoogleEmailTB			=	'//*[@id="identifierId"]'
GoogleEmailTBVal		=	'aecortest2019@gmail.com'
GoogleNextBTN			=	'//*[@id="identifierNext"]'
GooglePasswordTB		=	'//*[@name="password"]'
GooglePasswordTBVal		=	'password'
GooglePasswordNextBTN	=	'//*[@id="passwordNext"]'
FacebookLink			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/auth/facebook"]'
FacebookEmailVal		=	'sandeep.patel@aecordigital.com'
FacebookPasswordTB		=	'//*[@id="pass"]'
FacebookPasswordTBVal	=	'aecor12345'
FacebookLoginBTN		=	'//*[@id="loginbutton"]'
FacebookCreateLeagueLnk	=	'//a[@href="https://fantasyleague.aecordigitalqa.com/manage/division/create"]'	
#======================Create,edit,delete Admin user==================================
UserDD					=	'xpath=//*[@id="sidebar-scroll"]/div/div[3]/ul/li[2]/a'
AdminUser				=	'xpath=//*[@id="sidebar-scroll"]/div/div[3]/ul/li[2]/ul/li[1]/a'
AddNewAdminBTN			=	'//a[@href="https://fantasyleague.aecordigitalqa.com/admin/users/create"]'
FirstNameTB				=	'//*[@name="first_name"]'
FirstNameTBVal			=	'Sandeep'
LastNameTB				=	'//*[@name="last_name"]'
LastNameTBval			=	'Patel'
AdminUerEmailId			=	'sandeep.patel966@aecordigital.com'
UserTypeDD				=	'//*[@id="select2-role-container"]'
UserTypeVal				=	'//*[contains@id,"select2-role-result") and contains(@id,"-superadmin")]'
CreateAdminBTN			=	'//*[@id="main-container"]/div/form/div[2]/button'
FirstNameSearchTB		=	'//*[@id="filter-term"]'
SearchBTN				=	'//*[@id="main-container"]/div/form/div/div[1]/div/button'
CustomerIDField			=	'//*[@id="DataTables_Table_0"]/tbody/tr/td[1]'
CustAdminIdeditURL		=	'https://fantasyleague.aecordigitalqa.com/admin/users/${AdminID}/edit'
FirstNameUpdateVal		=	'Sandeep Update'
LastNameUpdateVal		=	'Patel Update'
UpdateEmailVal			=	'sandeep.patel96@aecordigital.com'
UpdateUserBTN			=	'//*[@id="main-container"]/div/form/div[2]/button'
DeleteIcon				=	'//*[@class="btn btn-sm btn-circle btn-alt-danger mr-5 mb-5 delete-confirmation-button"]'
OptionYes				=	'//*[@aria-label="Yes, delete it!"]'





















.





