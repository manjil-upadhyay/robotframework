
#zipping
# importing required modules
from zipfile import ZipFile
import os

def get_all_file_paths(directory):

                # initializing empty file paths list=====CHANGE NAME OF FILE WITH EXTENSION
                file_paths = ['./log.html']
                

                # crawling through directory and subdirectories
                for root, directories, files in os.walk(directory):
                        for filename in files:
                                # join the two strings in order to form the full filepath.
                                filepath = os.path.join(root, filename)
                                #filepath = './Test\\'
                                file_paths.append(filepath)

                # returning all file paths
                return file_paths

def main(): 
        # path to folder which needs to be zipped=====COPY THE ABOVE UPDATED NAME HERE WITH EXTENSION
        directory = './log.html'
        #directory = 'C://Users//devanshi//Desktop//Test.txt//'

        # calling function to get all file paths in the directory 
        file_paths = get_all_file_paths(directory) 

        # printing the list of all files to be zipped
        ##print('Following files will be zipped:')
        print('Following files will be Sent:')
        for file_name in file_paths:
        #for file_name in 'C://Users//devanshi//Desktop//Test.txt//':
                print(file_name)

        # writing files to a zipfile=====PUT PATH OF THE FILE WHERE YOU WANT YOUR ZIP FILE LIKE IN SHARED DRIVE SO THAT ONE WHO GET MAIL WILL ALSO ABLE TO ACCESS THE FILE
        #with ZipFile('C:\\Users\\devanshi\\Desktop\\manjil.zip','w') as zip:
        ##with ZipFile('.\manjil.zip','w') as zip:
        # writing each file one by one
        ##for file in file_paths:
        ##	zip.write(file)

        ##print('All files zipped successfully!')


if __name__ == "__main__":
        main()




#email configuration
# Python code to illustrate Sending mail with attachments
# from your Gmail account

# libraries to be imported
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

fromaddr = "aecortest2019@gmail.com"
toaddr = "mupadhyay@aecordigital.com","manjilupadhyay2016@gmail.com"

# instance of MIMEMultipart
msg = MIMEMultipart()

# storing the senders email address
msg['From'] = fromaddr

# storing the receivers email address
msg['To'] = toaddr

# storing the subject=====CHANGE SUBJECT AS PER YOUR REQUIRMENT
msg['Subject'] = "Automation Logs"

# string to store the body of the mail======CHANGE BODY PART AS PER YOUR NEED
body = "Please find attached logs."

# attach the body with the msg instance
msg = MIMEMultipart()
msg.attach(MIMEText(body, 'plain'))

# open the file to be sent
filename = "log.html"
#filename = "my_python_files.zip"=====COPY ABOVE PATH LIKE SHARED DRIVE
#attachment = open("C:\\Users\\devanshi\\Desktop\\manjil.zip", "rb")
attachment = open("./log.html")


# instance of MIMEBase and named as p
p = MIMEBase('application', 'octet-stream')

# To change the payload into encoded form
p.set_payload((attachment).read())

# encode into base64
encoders.encode_base64(p)

#msg.add_header('Content-Disposition', 'attachment', filename='bud.gif')=====GIVE FILE NAME AS PER YOU WANTED ZIP FILE TO BE SENT
p.add_header('Content-Disposition', 'attachment' , filename='log.html')

# attach the instance 'p' to instance 'msg'
msg.attach(p)

# creates SMTP session=====HERE THE SMTP SERVER DETAILS (FROM ADDRESS)WILL COME WITH PORT NUMBER I.E FOR GMAIL PORT NO IS 587
s = smtplib.SMTP('smtp.gmail.com', 587)

# start TLS for security
#s.ehlo()
s.starttls()

# Authentication=====THIS IS MY PASSWORD FROM WHERE I WANT TO SEND MY EMAIL (FROM ADDRESS)
#s.ehlo()
s.login(fromaddr, "Aecor1234")

# Converts the Multipart msg into a string
text = msg.as_string()

# sending the mail
s.sendmail(fromaddr, toaddr, text)

# terminating the session
s.quit()

print('Email has been sent successfully, Please check the logs!')


#zipping
# importing required modules
from zipfile import ZipFile
import os

def get_all_file_paths(directory):

                # initializing empty file paths list=====CHANGE NAME OF FILE WITH EXTENSION
                file_paths = ['./Report.html']

                # crawling through directory and subdirectories
                for root, directories, files in os.walk(directory):
                        for filename in files:
                                # join the two strings in order to form the full filepath.
                                filepath = os.path.join(root, filename)
                                #filepath = './Test\\'
                                file_paths.append(filepath)

                # returning all file paths
                return file_paths

def main(): 
        # path to folder which needs to be zipped=====COPY THE ABOVE UPDATED NAME HERE WITH EXTENSION
        directory = './Report.html'
        #directory = 'C://Users//devanshi//Desktop//Test.txt//'

        # calling function to get all file paths in the directory 
        file_paths = get_all_file_paths(directory) 

        # printing the list of all files to be zipped
        ##print('Following files will be zipped:')
        print('Following files will be Sent:')
        for file_name in file_paths:
        #for file_name in 'C://Users//devanshi//Desktop//Test.txt//':
                print(file_name)

        # writing files to a zipfile=====PUT PATH OF THE FILE WHERE YOU WANT YOUR ZIP FILE LIKE IN SHARED DRIVE SO THAT ONE WHO GET MAIL WILL ALSO ABLE TO ACCESS THE FILE
        #with ZipFile('C:\\Users\\devanshi\\Desktop\\manjil.zip','w') as zip:
        ##with ZipFile('.\manjil.zip','w') as zip:
        # writing each file one by one
        ##for file in file_paths:
        ##	zip.write(file)

        ##print('All files zipped successfully!')


if __name__ == "__main__":
        main()




#email configuration
# Python code to illustrate Sending mail with attachments
# from your Gmail account

# libraries to be imported
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

fromaddr = "aecortest2019@gmail.com"
toaddr = "mupadhyay@aecordigital.com","manjilupadhyay2016@gmail.com"

# instance of MIMEMultipart
msg = MIMEMultipart()

# storing the senders email address
msg['From'] = fromaddr

# storing the receivers email address
msg['To'] = toaddr

# storing the subject=====CHANGE SUBJECT AS PER YOUR REQUIRMENT
msg['Subject'] = "Automation Logs"

# string to store the body of the mail======CHANGE BODY PART AS PER YOUR NEED
body = "Please find attached report."

# attach the body with the msg instance
msg = MIMEMultipart()
msg.attach(MIMEText(body, 'plain'))

# open the file to be sent
filename = "Report.html"
#filename = "my_python_files.zip"=====COPY ABOVE PATH LIKE SHARED DRIVE
#attachment = open("C:\\Users\\devanshi\\Desktop\\manjil.zip", "rb")
attachment = open("./Report.html", "rb")

# instance of MIMEBase and named as p
p = MIMEBase('application', 'octet-stream')

# To change the payload into encoded form
p.set_payload((attachment).read())

# encode into base64
encoders.encode_base64(p)

#msg.add_header('Content-Disposition', 'attachment', filename='bud.gif')=====GIVE FILE NAME AS PER YOU WANTED ZIP FILE TO BE SENT
p.add_header('Content-Disposition', 'attachment' , filename='Report.html')

# attach the instance 'p' to instance 'msg'
msg.attach(p)

# creates SMTP session=====HERE THE SMTP SERVER DETAILS (FROM ADDRESS)WILL COME WITH PORT NUMBER I.E FOR GMAIL PORT NO IS 587
s = smtplib.SMTP('smtp.gmail.com', 587)

# start TLS for security
#s.ehlo()
s.starttls()

# Authentication=====THIS IS MY PASSWORD FROM WHERE I WANT TO SEND MY EMAIL (FROM ADDRESS)
#s.ehlo()
s.login(fromaddr, "Aecor1234")

# Converts the Multipart msg into a string
text = msg.as_string()

# sending the mail
s.sendmail(fromaddr, toaddr, text)

# terminating the session
s.quit()

print('Email has been sent successfully, Please check the logs!')

