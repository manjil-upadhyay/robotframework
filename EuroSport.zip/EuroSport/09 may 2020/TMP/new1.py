URL1='https://qa.wot.esrtmp.com/'
AdminDashboardBTNXP1='//*[@id="app"]/div[2]/header/div/ul/li/a'
EmailIdTBXP='//*[@id="loginForm"]/div[1]/input'
PasswordTBXP='//*[@id="loginForm"]/div[2]/input'
EmailIdTBVal='ndeopura@aecordigital.com'
PasswordTBVal='password'
LoginBTNXP='//*[@id="loginForm"]/button'

#==========================================Create tournament Page========================================================
CreatefulltournamentBTN1='//*[@id="dashboardPage"]/div/div[1]/div/div[2]/div[2]/button'
TournamentnameTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[1]/div[1]/div/div/input'
TournamentnameTBVal1='test ABCD'
MaximumteamsTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[1]/div[2]/div/div/input'
MaximumteamsTBVal1='16'
TournamentstartdateTBXP1='//*[@id="tournament_start_date"]'
TournamentstartdateTBVal1='01/03/2020'
TournamentenddateTBXP1='//*[@id="tournament_end_date"]'
TournamentenddateTBVal1='31/03/2020'
ShowoptionaldetailsBTNXP1='//*[@id="headingOne"]/a'
FirstnameTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[5]/div/input'
FirstnameTBVal1='MohammedHusen'
LastnameTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[6]/div/input'
LastnameTBVal1='Daudiya'
TelephoneTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[7]/div/input'
TelephoneTBVal1='9714695075'
SportparkTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[2]/div/input'
SportparkTBVal1='Trenthem Park'
AddressTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[3]/div/input'
AddressTBVal1='g/827,sdshh'
Town/CityTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[4]/div/input'
Town/CityTBVal1='vadodara'
PostcodeTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[5]/div/input'
PostcodeTBVal1='390019'
CountryDBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[6]/div/div/select'
CountryDBValXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[6]/div/div/select/option[13]'
OrganiserTBXP1='//*[@id="tournament_details"]/div[1]/div/div/form/div[8]/div[7]/div/input'
OrganiserTBVal1='jshds'









